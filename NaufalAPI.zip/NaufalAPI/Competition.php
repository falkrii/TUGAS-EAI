<?php
    
    $api_url = 'https://apiv3.apifootball.com/?action=get_leagues&country_id=6&APIkey=e6ecc45affa94f8ea6caecfa29c2d820bc1b729713343d7ae070e4c94135a181';
    $data = json_decode(file_get_contents($api_url), true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Competitions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5; 
            font-family: Arial, sans-serif;
        }
        .navbar {
            background-color: #343a40;
        }
        .navbar-brand {
            color: #ffffff;
            font-weight: bold;
        }
        .card {
            margin-bottom: 20px;
            max-width: 300px; 
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease-in-out;
        }
        .card:hover {
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.2);
        }
        .card-img-top {
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }
        .card-body {
            padding: 20px;
        }
        .card-title {
            font-size: 18px;
            font-weight: bold;
            color: #343a40;
            margin-bottom: 10px;
        }
        .card-subtitle {
            font-size: 16px;
            color: #6c757d;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>


<div class="container mt-5">
    <h1 class="text-center mb-5">List of Competition</h1>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php foreach ($data as $row): ?>
            <div class="col">
                <div class="card">
                    <img src="<?= $row['league_logo'] ?>" class="card-img-top" alt="League Logo">
                    <div class="card-body">
                        <h2 class="card-title"><?= $row['league_name'] ?></h2>
                        <h3 class="card-subtitle">Country: <?= $row['country_name'] ?></h3>
                        <p class="card-subtitle">Country ID: <?= $row['country_id'] ?></p>
                        <p class="card-subtitle">League ID: <?= $row['league_id'] ?></p>
                        <p class="card-subtitle">Season: <?= $row['league_season'] ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
