<?php
    $api_link = 'https://apiv3.apifootball.com/?action=get_countries&APIkey=e6ecc45affa94f8ea6caecfa29c2d820bc1b729713343d7ae070e4c94135a181';
    $data = file_get_contents($api_link);
    $countries = json_decode($data, true);
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Country</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            margin-bottom: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .card-img-top {
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            height: 200px;
            object-fit: cover;
        }
        .card-body {
            text-align: center;
        }
        h1 {
            color: #343a40;
            text-align: center;
            margin-top: 50px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .card-text {
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>List of Country</h1>
        <div class="row">
            <?php foreach ($countries as $country): ?>
                <div class="col-3">
                    <div class="card">
                        <img src="<?php echo $country['country_logo'] ?>" class="card-img-top" alt="Country Flag">
                        <div class="card-body">
                            <h3><?php echo $country['country_id'] ?></h3>
                            <p class="card-text"><?php echo $country['country_name'] ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
