<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Welcome to API Football</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <style>
    body {
      background-color: #f8f9fa; 
      font-family: Arial, sans-serif;
    }
    h1 {
      color: #343a40;
      text-align: center;
      margin-top: 50px;
      font-weight: bold;
      text-transform: uppercase;
    }
    .navbar {
      background-color: #343a40;
    }
    .navbar-brand {
      color: #ffffff;
      font-weight: bold;
    }
    .btn-outline-light {
      color: #ffffff;
      border-color: #ffffff;
    }
    .container {
      margin-top: 50px;
    }
    .btn-warning {
      background-color: #ffc107;
      border-color: #ffc107;
      color: #343a40;
      width: 100%;
      margin-bottom: 20px;
      font-weight: bold;
      text-transform: uppercase;
    }
    .btn-warning:hover {
      background-color: #ffca28;
      border-color: #ffca28;
      color: #343a40;
    }
    .btn-blue {
      background-color: #7ea5ff;
      border-color: #7ea5ff;
      color: #ffffff;
    }
    .btn-blue:hover {
      background-color: #6c8cd5;
      border-color: #6c8cd5;
      color: #ffffff;
    }
    .btn-icon {
      font-size: 20px;
      margin-right: 5px;
    }
    .row {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .col-md-6 {
      margin-bottom: 20px;
    }
    .navbar-brand-container {
      background-color: #292b2c; 
      padding: 10px 20px; 
      border-radius: 5px; 
    }
  </style>
</head>
<body>
  <h1>Explore Football Teams</h1>
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <div class="navbar-brand-container">
        <a class="navbar-brand">Choose One</a>
      </div>
    </div>
  </nav>
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <a href="http://localhost:8080/NAUFALAPI/Competition.php" class="text-start">
          <button class="btn btn-warning btn-lg" type="button"><i class="fas fa-globe btn-icon"></i>Competition</button>
        </a>
      </div>
      <div class="col-md-6">
        <a href="http://localhost:8080/NAUFALAPI/Country.php" class="text-start">
          <button class="btn btn-warning btn-lg" type="button"><i class="fas fa-trophy btn-icon"></i>Country</button>
        </a>
      </div>
    </div>
  </div>
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js" integrity="sha384-cLjEACuWTKsFy9Aq6K0pJ5z/Qi0X/Kg3n3O8kMDZPgpUyM3ocx6OJLg5It7l9/Ts" crossorigin="anonymous"></script>
</body>
</html>
